<?php
include("../config/db.php");

$data = json_decode(file_get_contents("php://input"), true);

$username = $data['username'];
$email = $data['email'];
$password = password_hash($data['password'], PASSWORD_DEFAULT);

mysqli_query($conn,
"INSERT INTO users (username,email,password)
 VALUES ('$username','$email','$password')");

echo json_encode(["status"=>"success"]);
?>
