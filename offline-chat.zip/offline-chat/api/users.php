<?php
include("../config/db.php");

$res = mysqli_query($conn,"SELECT id, username FROM users");
$users = [];

while($row = mysqli_fetch_assoc($res)){
    $users[] = $row;
}

echo json_encode($users);
?>
