<?php
$conn = mysqli_connect("localhost", "root", "", "chat_app");

if (!$conn) {
    die("Database connection failed");
}
?>
