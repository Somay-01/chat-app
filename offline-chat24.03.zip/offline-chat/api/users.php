<?php
include("../config/db.php");

$myId = $_GET['my_id'];

$sql = "
SELECT u.id, u.username,
(
SELECT COUNT(*) 
FROM messages 
WHERE sender_id = u.id 
AND receiver_id = $myId 
AND is_read = 0
) AS unread
FROM users u
WHERE u.id != $myId
";

$res = mysqli_query($conn,$sql);

$users = [];

while($row = mysqli_fetch_assoc($res)){
    $users[] = $row;
}

header('Content-Type: application/json');
echo json_encode($users);

?>