<?php

include("../config/db.php");

$sender = $_POST["sender_id"];
$receiver = $_POST["receiver_id"];
$message = $_POST["message"];

$file_path = "";
$file_type = "";

// check if file uploaded
if(isset($_FILES["file"])){

$file = $_FILES["file"];

$filename = time() . "_" . $file["name"];
$target = "../uploads/" . $filename;

move_uploaded_file($file["tmp_name"], $target);

$file_path = "uploads/" . $filename;

// detect file type
$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

if(in_array($ext, ["jpg","jpeg","png","gif"])){
$file_type = "image";
}
else if(in_array($ext, ["mp4","webm"])){
$file_type = "video";
}
else{
$file_type = "document";
}

}

$sql = "INSERT INTO messages (sender_id,receiver_id,message,file_path,file_type)
VALUES ('$sender','$receiver','$message','$file_path','$file_type')";

mysqli_query($conn,$sql);

echo json_encode(["status"=>"success"]);

?>