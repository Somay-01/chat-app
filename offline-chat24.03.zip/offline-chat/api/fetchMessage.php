<?php

include("../config/db.php");

$sender = $_GET['sender_id'];
$receiver = $_GET['receiver_id'];

$sql = "
SELECT *
FROM messages
WHERE (sender_id = $sender AND receiver_id = $receiver)
OR (sender_id = $receiver AND receiver_id = $sender)
ORDER BY id ASC
";

$result = $conn->query($sql);

$messages = [];

while($row = $result->fetch_assoc()){
    $messages[] = $row;
}

echo json_encode($messages);

?>