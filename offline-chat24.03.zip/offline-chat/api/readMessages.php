<?php

include("../config/db.php");

$sender = $_GET['sender_id'];
$receiver = $_GET['receiver_id'];

$conn->query("
UPDATE messages
SET is_read = 1,
    seen = 1
WHERE sender_id = $receiver 
AND receiver_id = $sender
");

?>