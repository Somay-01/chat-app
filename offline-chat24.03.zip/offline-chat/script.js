/* ================= REGISTER ================= */
function register() {
  const username = document.getElementById("username").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  if (!username || !email || !password) {
    alert("Fill all fields");
    return;
  }

  fetch("api/register.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password })
  }).then(() => {
    alert("Registered successfully");
    location.href = "index.html";
  });
}

/* ================= LOGIN ================= */
function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  fetch("api/login.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  })
    .then(r => r.json())
    .then(d => {
      if (d.status === "success") {
        localStorage.clear();
        localStorage.setItem("uid", d.id);
        location.href = "chat.html";
      } else {
        alert("Invalid login");
      }
    });
}

/* ================= CHAT ================= */
let selectedUser = null;

/* Load users */
function loadUsers() {
  const usersDiv = document.getElementById("users");
  usersDiv.innerHTML = "";
  const myId = localStorage.getItem("uid");

  fetch(`api/users.php?my_id=${myId}`)
    .then(r => r.json())
    .then(users => {
      users.forEach(u => {
        if (u.id == myId) return;

        const div = document.createElement("div");
        div.className = "user";
        div.innerText = u.username;

        if (u.unread > 0) {
          div.innerText += " (" + u.unread + ")";
        }

        div.onclick = () => {
          document.querySelectorAll(".user")
            .forEach(x => x.classList.remove("active"));

          div.classList.add("active");
          selectedUser = u.id;

          document.getElementById("chatWith").innerText = u.username;

          loadMessages();
        };

        usersDiv.appendChild(div);
      });
    });
}

/* ================= SEND MESSAGE ================= */
function sendMessage() {

  if (!selectedUser) {
    alert("Select user first");
    return;
  }

  const msg = document.getElementById("msg").value;
  const file = document.getElementById("fileUpload").files[0];

  const formData = new FormData();

  formData.append("sender_id", localStorage.getItem("uid"));
  formData.append("receiver_id", selectedUser);
  formData.append("message", msg);

  if (file) {
    formData.append("file", file);
  }

  fetch("api/sendMessage.php", {
    method: "POST",
    body: formData
  })
    .then(() => {
      document.getElementById("msg").value = "";
      document.getElementById("fileUpload").value = "";
      loadMessages();
    });

}

/* ================= LOAD MESSAGES ================= */
function loadMessages() {
  if (!selectedUser) return;

  const messagesDiv = document.getElementById("messages");
  messagesDiv.innerHTML = "";

  fetch(
    `api/fetchMessage.php?sender_id=${localStorage.getItem("uid")}&receiver_id=${selectedUser}`
  )
    .then(r => r.json())
    .then(data => {

      if (data.length === 0) {
        messagesDiv.innerHTML = "<p>No messages yet</p>";
        return;
      }

      let unreadInserted = false;

      data.forEach(m => {

        // UNREAD DIVIDER
        if (
          m.is_read == 0 &&
          !unreadInserted &&
          m.sender_id != localStorage.getItem("uid")
        ) {
          const divider = document.createElement("div");
          divider.className = "unread-divider";
          divider.innerText = "Unread messages";
          messagesDiv.appendChild(divider);
          unreadInserted = true;
        }

        const div = document.createElement("div");
        div.classList.add("message");

        if (m.sender_id == localStorage.getItem("uid")) {
          div.classList.add("sent");
        } else {
          div.classList.add("received");
        }

        const date = new Date(m.created_at);

        const time = date.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit"
        });

        let tick = "";

        if (m.sender_id == localStorage.getItem("uid")) {
          tick = m.seen == 1 ? "✓✓" : "✓";
        }

        /* ===== FILE SUPPORT ===== */

        let content = "";

        if (m.message) {
          content += m.message;
        }

        if (m.file_path) {

          if (m.file_type === "image") {
            content += `<br><img src="${m.file_path}" width="150">`;
          }
          else if (m.file_type === "video") {
            content += `<br><video width="200" controls>
                          <source src="${m.file_path}">
                        </video>`;
          }
          else {
            content += `
            <div class="file-box">
             📄 <a href="${m.file_path}" target="_blank">Download File</a>
            </div>
            `;
          }

        }

        div.innerHTML = `
          ${content}
          <div class="time">${time} ${tick}</div>
        `;

        messagesDiv.appendChild(div);

      });

      messagesDiv.scrollTop = messagesDiv.scrollHeight;

      fetch(
        `api/readMessages.php?sender_id=${localStorage.getItem("uid")}&receiver_id=${selectedUser}`
      );

    });
}

/* ================= RESET PASSWORD ================= */
function resetPassword() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("newPassword").value;

  if (email === "" || password === "") {
    alert("Please fill all fields");
    return;
  }

  fetch("api/forgot.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email: email,
      password: password
    })
  })
    .then(res => res.json())
    .then(data => {
      if (data.status === "success") {
        alert("Password reset successful");
        window.location.href = "index.html";
      } else {
        alert("Email not found");
      }
    });
}

/* AUTO REFRESH */
setInterval(() => {
  if (selectedUser) {
    loadMessages();
  }
}, 2000);

/* ENTER KEY SEND */
document.addEventListener("DOMContentLoaded", () => {

  const msgInput = document.getElementById("msg");
  const fileInput = document.getElementById("fileUpload");
  const fileName = document.getElementById("fileName");

  // ENTER KEY
  if (msgInput) {
    msgInput.addEventListener("keypress", function (e) {
      if (e.key === "Enter") {
        e.preventDefault();
        sendMessage();
      }
    });
  }

  // FILE NAME SHOW
  if (fileInput && fileName) {
    fileInput.onchange = () => {
      fileName.innerText = fileInput.files[0]
        ? fileInput.files[0].name
        : "";
    };
  }

});

/* SEARCH USERS */
document.addEventListener("DOMContentLoaded", () => {
  const search = document.getElementById("searchUser");

  if (search) {
    search.addEventListener("keyup", () => {
      const filter = search.value.toLowerCase().trim();

      document.querySelectorAll(".user").forEach(user => {
        const name = user.innerText.toLowerCase();

        if (filter === "" || name.includes(filter)) {
          user.style.display = "block";
        } else {
          user.style.display = "none";
        }
      });
    });
  }
});

/* LOGOUT */
document.getElementById("logout").onclick = () => {
  localStorage.clear();
  window.location = "index.html";
};

/* DARK MODE */
document.addEventListener("DOMContentLoaded", () => {

  // render icons
  lucide.createIcons();

  const toggle = document.getElementById("darkToggle");

  if (toggle) {
    toggle.addEventListener("click", () => {

      document.body.classList.toggle("dark-mode");

      if (document.body.classList.contains("dark-mode")) {
        localStorage.setItem("theme", "dark");
        toggle.innerHTML = '<i data-lucide="sun"></i>';
      } else {
        localStorage.setItem("theme", "light");
        toggle.innerHTML = '<i data-lucide="moon"></i>';
      }

      // re-render icon after change
      lucide.createIcons();

    });
  }

});