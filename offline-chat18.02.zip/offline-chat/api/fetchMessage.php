<?php
include("../config/db.php");

$sid = $_GET['sender_id'];
$rid = $_GET['receiver_id'];

$res = mysqli_query($conn,
"SELECT * FROM messages
 WHERE (sender_id=$sid AND receiver_id=$rid)
 OR (sender_id=$rid AND receiver_id=$sid)");

$msgs = [];
while($row = mysqli_fetch_assoc($res)){
    $msgs[] = $row;
}

echo json_encode($msgs);
?>
