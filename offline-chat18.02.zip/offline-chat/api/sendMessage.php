<?php
include("../config/db.php");

$data = json_decode(file_get_contents("php://input"), true);

$sid = $data['sender_id'];
$rid = $data['receiver_id'];
$msg = $data['message'];

mysqli_query($conn,
"INSERT INTO messages (sender_id,receiver_id,message)
 VALUES ($sid,$rid,'$msg')");

echo json_encode(["status"=>"sent"]);
?>
