<?php
include("../config/db.php");

$data = json_decode(file_get_contents("php://input"), true);

$email = $data['email'];
$newPassword = password_hash($data['password'], PASSWORD_DEFAULT);

// check if user exists
$check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

if (mysqli_num_rows($check) > 0) {

    // update password
    mysqli_query($conn,
      "UPDATE users SET password='$newPassword' WHERE email='$email'"
    );

    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "not_found"]);
}
?>

