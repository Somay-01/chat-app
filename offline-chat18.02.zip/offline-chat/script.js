/* ================= REGISTER ================= */
function register() {
  const username = document.getElementById("username").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  if (!username || !email || !password) {
    alert("Fill all fields");
    return;
  }

  fetch("api/register.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password })
  }).then(() => {
    alert("Registered successfully");
    location.href = "index.html";
  });
}

/* ================= LOGIN ================= */
function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  fetch("api/login.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  })
    .then(r => r.json())
    .then(d => {
      if (d.status === "success") {
        localStorage.clear();
        localStorage.setItem("uid", d.id);
        location.href = "chat.html";
      } else {
        alert("Invalid login");
      }
    });
}

/* ================= CHAT ================= */
let selectedUser = null;

/* Load users */
function loadUsers() {
  const usersDiv = document.getElementById("users");
  usersDiv.innerHTML = "";
  const myId = localStorage.getItem("uid");

  fetch("api/users.php")
    .then(r => r.json())
    .then(users => {
      users.forEach(u => {
        if (u.id == myId) return;

        const div = document.createElement("div");
        div.className = "user";
        div.innerText = u.username;

        div.onclick = () => {
          document.querySelectorAll(".user")
            .forEach(x => x.classList.remove("active"));

          div.classList.add("active");
          selectedUser = u.id;
          loadMessages();
        };

        usersDiv.appendChild(div);
      });
    });
}

/* Send message */
function sendMessage() {
  if (!selectedUser) {
    alert("Select a user first");
    return;
  }

  const msgInput = document.getElementById("msg");
  const message = msgInput.value.trim();
  if (!message) return;

  fetch("api/sendMessage.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      sender_id: localStorage.getItem("uid"),
      receiver_id: selectedUser,
      message: message
    })
  }).then(() => {
    msgInput.value = "";
    loadMessages();
  });
}

/* Load messages (LEFT / RIGHT LOGIC) */
function loadMessages() {
  if (!selectedUser) return;

  const messagesDiv = document.getElementById("messages");
  messagesDiv.innerHTML = "";

  fetch(
    `api/fetchMessage.php?sender_id=${localStorage.getItem("uid")}&receiver_id=${selectedUser}`
  )
    .then(r => r.json())
    .then(data => {
      if (data.length === 0) {
        messagesDiv.innerHTML = "<p>No messages yet</p>";
        return;
      }

      data.forEach(m => {
        const div = document.createElement("div");
        div.classList.add("message");

        // 🔥 LEFT / RIGHT DECISION
        if (m.sender_id == localStorage.getItem("uid")) {
          div.classList.add("sent");      // right side
        } else {
          div.classList.add("received");  // left side
        }

        div.innerText = m.message;
        messagesDiv.appendChild(div);
      });

      messagesDiv.scrollTop = messagesDiv.scrollHeight;
    });

    function resetPassword() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("newPassword").value;

  if (email === "" || password === "") {
    alert("Please fill all fields");
    return;
  }

  fetch("api/forgotPassword.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email: email,
      password: password
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === "success") {
      alert("Password reset successful");
      window.location.href = "index.html";
    } else {
      alert("Email not found");
    }
  });
}

}
