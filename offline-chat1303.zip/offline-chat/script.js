/* ================= REGISTER ================= */
function register() {
  const username = document.getElementById("username").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  if (!username || !email || !password) {
    alert("Fill all fields");
    return;
  }

  fetch("api/register.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password })
  }).then(() => {
    alert("Registered successfully");
    location.href = "index.html";
  });
}

/* ================= LOGIN ================= */
function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  fetch("api/login.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  })
    .then(r => r.json())
    .then(d => {
      if (d.status === "success") {
        localStorage.clear();
        localStorage.setItem("uid", d.id);
        location.href = "chat.html";
      } else {
        alert("Invalid login");
      }
    });
}

/* ================= CHAT ================= */
let selectedUser = null;

/* Load users */
function loadUsers() {
  const usersDiv = document.getElementById("users");
  usersDiv.innerHTML = "";
  const myId = localStorage.getItem("uid");

  fetch(`api/users.php?my_id=${myId}`)
    .then(r => r.json())
    .then(users => {
      users.forEach(u => {
        if (u.id == myId) return;

        const div = document.createElement("div");
        div.className = "user";
        div.innerText = u.username;
        if (u.unread > 0) {
          div.innerText += " (" + u.unread + ")";
        }

        div.onclick = () => {
          document.querySelectorAll(".user")
            .forEach(x => x.classList.remove("active"));

          div.classList.add("active");
          selectedUser = u.id;

          document.getElementById("chatWith").innerText = u.username;

          loadMessages();
        };

        usersDiv.appendChild(div);
      });
    });
}

/* Send message */
function sendMessage() {
  if (!selectedUser) {
    alert("Select a user first");
    return;
  }

  const msgInput = document.getElementById("msg");
  const message = msgInput.value.trim();
  if (!message) return;

  fetch("api/sendMessage.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      sender_id: localStorage.getItem("uid"),
      receiver_id: selectedUser,
      message: message
    })
  }).then(() => {
    msgInput.value = "";
    loadMessages();
  });
}

/* Load messages (LEFT / RIGHT LOGIC) */
function loadMessages() {
  if (!selectedUser) return;

  const messagesDiv = document.getElementById("messages");
  messagesDiv.innerHTML = "";

  fetch(
    `api/fetchMessage.php?sender_id=${localStorage.getItem("uid")}&receiver_id=${selectedUser}`
  )
    .then(r => r.json())
    .then(data => {

      if (data.length === 0) {
        messagesDiv.innerHTML = "<p>No messages yet</p>";
        return;
      }

      let unreadInserted = false;

      data.forEach(m => {

        // INSERT UNREAD DIVIDER
        if (
          m.is_read == 0 &&
          !unreadInserted &&
          m.sender_id != localStorage.getItem("uid")
        ) {

          const divider = document.createElement("div");
          divider.className = "unread-divider";
          divider.innerText = "Unread messages";

          messagesDiv.appendChild(divider);

          unreadInserted = true;
        }

        const div = document.createElement("div");
        div.classList.add("message");

        // LEFT / RIGHT MESSAGE
        if (m.sender_id == localStorage.getItem("uid")) {
          div.classList.add("sent");
        } else {
          div.classList.add("received");
        }

        const date = new Date(m.created_at);

        const time = date.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit"
        });

        // message ticks
        let tick = "";

        if (m.sender_id == localStorage.getItem("uid")) {
          tick = m.seen == 1 ? "✓✓" : "✓";
        }

        div.innerHTML = `
          ${m.message}
          <div class="time">${time} ${tick}</div>
        `;

        messagesDiv.appendChild(div);

      });

      messagesDiv.scrollTop = messagesDiv.scrollHeight;

      // mark messages as read AFTER rendering messages
      fetch(
        `api/readMessages.php?sender_id=${localStorage.getItem("uid")}&receiver_id=${selectedUser}`
      );

    });
}

/* ==========reset password==============*/

function resetPassword() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("newPassword").value;

  if (email === "" || password === "") {
    alert("Please fill all fields");
    return;
  }

  fetch("api/forgot.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email: email,
      password: password
    })
  })
    .then(res => res.json())
    .then(data => {
      if (data.status === "success") {
        alert("Password reset successful");
        window.location.href = "index.html";
      } else {
        alert("Email not found");
      }
    });
}
// auto refresh messages every 2 seconds
setInterval(() => {
  if (selectedUser) {
    loadMessages();
  }
}, 2000);


document.addEventListener("DOMContentLoaded", () => {

  const msgInput = document.getElementById("msg");

  if (msgInput) {
    msgInput.addEventListener("keypress", function (e) {

      if (e.key === "Enter") {
        e.preventDefault();
        sendMessage();
      }

    });
  }

});
// search-user

document.addEventListener("DOMContentLoaded", () => {

  const search = document.getElementById("searchUser");

  if (search) {

    search.addEventListener("keyup", () => {

      const filter = search.value.toLowerCase().trim();

      document.querySelectorAll(".user").forEach(user => {

        const name = user.innerText.toLowerCase();

        if (filter === "" || name.includes(filter)) {
          user.style.display = "block";
        } else {
          user.style.display = "none";
        }

      });

    });

  }

});

//logout
document.getElementById("logout").onclick = () => {

  localStorage.clear();

  window.location = "index.html";

};

// dark-mode
const toggle = document.getElementById("darkToggle");

if(toggle){

  toggle.onclick = () => {

    document.body.classList.toggle("dark-mode");

    if(document.body.classList.contains("dark-mode")){
      localStorage.setItem("theme","dark");
      toggle.innerHTML="☀️";
    }else{
      localStorage.setItem("theme","light");
      toggle.innerHTML="🌙";
    }

  };

}

/* load saved theme */

if(localStorage.getItem("theme")==="dark"){
  document.body.classList.add("dark-mode");
}


